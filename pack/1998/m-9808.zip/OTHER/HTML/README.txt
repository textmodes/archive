



this




		is the new, revolutionary,
		skin-revitalizing,
		mistigris html gallery.





design by weird
concept by cthulu



yes, view the whole pack using a browser!  


instructions for a successful life
----------------------------------

netscape is best.
internet explorer is ok.
(but we don't want to support bill gates, do we?)
opera is fine, too.  but some graphics may not display correctly.

there is no need to download the low resolution disk (a) of the pack, it's
all included in this html gallery disk.  to view the hirez, you must
download the hirez disk (b).  same with the music (disk c).  and to 
listen to the music, you'll need the modplug plugin.  






				questions, comments, love letters:
				e-mail weird - high5@odelay.dyn.ml.org

