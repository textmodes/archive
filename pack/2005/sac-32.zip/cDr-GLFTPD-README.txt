


    ______ ______ ___ ___ ______ ______ _______ _______ ______
 o  \   _//_    //  //  //  ___//      \\_    //  ____//_    /:
 :_/   /  _/   /    \   \\___  o         /   /   ___/  _/   /o|
 |\_______\_____ _______/______    /\________\_________\_____||
 ||-----------------------cDr/____/SAC-----------------------||
 ||                                                          ||
 ||                                                          ||
 || Here is a complete set of ascii logos to be used on your ||
 || local GLFTPD! They've all been tested and seems to work  ||
 || fine and i havent found anything major that i've missed  ||
 || yet atleast! There should be plenty of new stuff for all ||
 || of you who are bored of the default GLFTPD asciis.       ||
 ||                                                          ||
 ||                                                          ||
 || I have not bothered to test these on IOFTPD and all the  ||
 || the other crap that is out there, but if you like them & ||
 || want to use them, feel free just dont fuckup the ascii's ||
 || with your "homemade" designs.                            ||
 || If you want to alter the logos, do them from scratch     ||
 || yourself as ive put lots of time on doing these.         ||
 ||                                                          ||
 ||                                                          ||
 || Thanx to everyone who requested/nagged me to create this ||
 || final set of GLFTPD logos, you all know who you are! :-) ||
 ||                                                          ||
 || I renamed and put the correct names on all header files  ||
 || etc, all files are included in the cDr-glftpd.zip. Just  ||
 || unpack these files to your /glftpd dir and enjoy!        ||
 ||                                                          ||
 || Feel free to drop me a /msg crusader on EFNET @ #SAC     ||
 ||                                                          ||
 ||                                                          ||
 ||                     Signed: CRUSADER OF SAC / SiNCE 1994 ||
 :|_ ______________________________________________________ _|:
  |((______________________________________________________))|
  |/                                                        \|
  :                                                          :

